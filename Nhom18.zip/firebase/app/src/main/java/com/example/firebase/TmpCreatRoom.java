package com.example.firebase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.google.firebase.database.FirebaseDatabase;

public class TmpCreatRoom extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tmp_creat_room);
        Intent intent=getIntent();
        String[] data=intent.getStringArrayExtra("data");
        FirebaseDatabase.getInstance().getReference().child("Rooms").child(data[0]).child(data[1]).child("1").setValue(data[2]+":"+"YOU CREATED THIS ROOM!");
        // set id into user
        FirebaseDatabase.getInstance().getReference().child("Users").child(data[3]).child(data[2]).child(data[0]).setValue(data[1]);
        Intent intent1=new Intent();
        intent1.setClass(TmpCreatRoom.this,ListRoom.class);
        startActivity(intent1);
    }
}