package com.example.firebase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SettingRoom extends AppCompatActivity {
    private TextView tvRoomName;
    private TextView tvIdRoom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting_room);

        Intent intent=getIntent();
        final String[] data=intent.getStringArrayExtra("data");
        final String txt_nickname=data[1];
        final String roomName=data[0].split("-")[0];
        final String idRoom=data[0].split("-")[1];
        tvIdRoom=findViewById(R.id.id_room);
        tvRoomName=findViewById(R.id.tvRoomName);
        tvIdRoom.setText(idRoom);
        tvRoomName.setText(roomName);

    }
}