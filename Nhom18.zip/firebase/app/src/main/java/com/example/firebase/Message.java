package com.example.firebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Message extends AppCompatActivity {
    private ListView listView;
    private Button btRoomName;
    private EditText edMessage;
    private ImageView imSend;
    private ImageView imTim;
    private ImageView imSetting;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        //get data
        Intent intent=getIntent();
        final String[] data=intent.getStringArrayExtra("data");
        final String txt_nickname=data[1];
        final String roomName=data[0].split("-")[0];
        final String idRoom=data[0].split("-")[1];
        //Toast.makeText(Message.this,"roomname= "+roomName,Toast.LENGTH_SHORT).show();
        //Toast.makeText(Message.this,"idroom= "+idRoom,Toast.LENGTH_SHORT).show();

        btRoomName=findViewById(R.id.room_name);
        btRoomName.setText(roomName);
        edMessage=findViewById(R.id.edt_message);
        imTim=findViewById(R.id.tim);
        imSetting=findViewById(R.id.setting);
        imSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent23 = new Intent(Message.this,SettingRoom.class);
                String[] arrrayCourse={data[0],txt_nickname};
                intent23.putExtra("data",arrrayCourse);
                startActivity(intent23);
            }
        });


        final long[] cout = {0};
        DatabaseReference reference11 = FirebaseDatabase.getInstance().getReference().child("Rooms").child(idRoom).child(roomName);
        reference11.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot11) {
                cout[0] = (long) dataSnapshot11.getChildrenCount();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

        imSend=findViewById(R.id.send);

        imSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               String txtMessage=edMessage.getText().toString();
               if(TextUtils.isEmpty(txtMessage)){
                   Toast.makeText(Message.this,"Message is empty!",Toast.LENGTH_SHORT).show();
               } else {
                   FirebaseDatabase.getInstance().getReference().child("Rooms").child(idRoom).child(roomName).child(String.valueOf(cout[0]+1)).setValue("\uD83D\uDE4D"+txt_nickname+":\n"+txtMessage);
                   edMessage.setText("");
               }
            }
        });
        imTim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseDatabase.getInstance().getReference().child("Rooms").child(idRoom).child(roomName).child(String.valueOf(cout[0]+1)).setValue("\uD83D\uDE4D"+txt_nickname+":\n"+"\uD83D\uDC99");
            }
        });


        listView=findViewById(R.id.messages);
        final ArrayList<String> list=new ArrayList<>();
        final ArrayAdapter adapter = new ArrayAdapter<String>(Message.this,R.layout.activity_chat_tmp,list);
        listView.setAdapter(adapter);

        final DatabaseReference reference =FirebaseDatabase.getInstance().getReference().child("Rooms").child(idRoom).child(roomName);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list.clear();
                for(DataSnapshot data:dataSnapshot.getChildren()){
                   // Toast.makeText(Message.this,"data= "+data.getValue().toString(),Toast.LENGTH_SHORT).show();

                    list.add(data.getValue().toString());




                }

                adapter.notifyDataSetChanged();
                listView.smoothScrollToPosition(list.size()-1);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



    }
}