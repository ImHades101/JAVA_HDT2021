package com.example.firebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Menu extends AppCompatActivity {
    private Button listRoom;
    private Button join;
    private Button bt_info;
    private Button create;
    private ImageView imLogout;
    private String a; // nickname
    private ImageView imInfoUser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);


        imLogout=findViewById(R.id.logout);
        imLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Toast.makeText(Menu.this,"Logn out!",Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Menu.this,MainActivity.class));
            }
        });


        bt_info=findViewById(R.id.info);
        final String idUser; //dung final để được xài trong hàm con
        idUser = FirebaseAuth.getInstance().getCurrentUser().getUid();
        //Toast.makeText(Menu.this,"iduser= "+idUser,Toast.LENGTH_SHORT).show();
        final DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String dataa = null;
                for(DataSnapshot data: dataSnapshot.getChildren()) {
                    if (data.child(idUser).exists()) {
                        // tách chuỗi lấy giá trị nickname
                        a=data.child(idUser).getValue().toString();
                        String[] words = a.split("=");
                        a=words[0].substring(1);
                        bt_info.setText(a);
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
        imInfoUser=findViewById(R.id.avatar);
        imInfoUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2= new Intent();
                intent2.setClass(Menu.this,InfoUsers.class);
                intent2.putExtra("nickname",a);
                startActivity(intent2);
            }
        });

        join=findViewById(R.id.join);
        create=findViewById(R.id.room);
        listRoom=findViewById(R.id.lists_room);
        //lists room
        listRoom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2= new Intent();
                intent2.setClass(Menu.this,ListRoom.class);
                intent2.putExtra("nickname",a);
                startActivity(intent2);
            }
        });



        //join ROOM
        join.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2= new Intent();
                intent2.setClass(Menu.this,JoinRoom.class);
                intent2.putExtra("nickname",a);
                startActivity(intent2);
            }
        });
        //CREAT ROOM
        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent();
                intent.setClass(Menu.this,CreateRoom.class);
                intent.putExtra("nickname",a);
                startActivity(intent);
            }
        });




    }
}