package com.example.firebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SignUp extends AppCompatActivity {
    EditText email;
    EditText password;
    Button  btLogin;
    private FirebaseAuth auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        email = findViewById(R.id.email1);
        password=findViewById(R.id.pass1);
        btLogin=findViewById(R.id.btsignup1);
        auth=FirebaseAuth.getInstance();
        btLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // lấy text plain của email và pass
                String txt_email= email.getText().toString();
                String txt_password=password.getText().toString();
                //Toast.makeText(Login.this,"Đăng nhập"+txt_email,Toast.LENGTH_SHORT).show();
                // kiểm tra giá trị có empty ko
                if(TextUtils.isEmpty(txt_email) || TextUtils.isEmpty(txt_password)){
                    Toast.makeText(SignUp.this,"email or password empty!",Toast.LENGTH_SHORT).show();
                }else if(txt_password.length()<6){
                    Toast.makeText(SignUp.this,"password ngan!",Toast.LENGTH_SHORT).show();

                }else{registerUser(txt_email,txt_password);}
            }
        });

    }

    private void registerUser(String email, String password) {
        auth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(SignUp.this,new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Toast.makeText(SignUp.this,"Đăng nhập thành công!",Toast.LENGTH_SHORT).show();
                    Intent intent2=new Intent();
                    intent2.setClass(SignUp.this,CreatNickName.class);
                    startActivity(intent2);
                }else{
                    Toast.makeText(SignUp.this,"Đăng nhập không thành công!",Toast.LENGTH_SHORT).show();

                }

            }
        });
    }
}