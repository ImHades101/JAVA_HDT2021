package com.example.firebase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class InfoUsers extends AppCompatActivity {
    private Button btNickname;
    private Button btEmail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_users);

        Intent intent =getIntent();
        String txt_nickname=intent.getStringExtra("nickname");

        btEmail=findViewById(R.id.btn_email);
        btNickname=findViewById(R.id.btn_nickname);
        btNickname.setText(txt_nickname);
        String email; //dung final để được xài trong hàm con
        email = FirebaseAuth.getInstance().getCurrentUser().getEmail();
        btEmail.setText(email);

    }
}