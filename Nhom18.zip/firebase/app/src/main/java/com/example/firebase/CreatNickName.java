package com.example.firebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class CreatNickName extends AppCompatActivity {
    private EditText name;
    private Button create;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creat_nick_name);
        name=findViewById(R.id.nickname);
        create=findViewById(R.id.create);

        final String idUser; //dung final để được xài trong hàm con
        idUser = FirebaseAuth.getInstance().getCurrentUser().getUid();


        DatabaseReference reference =FirebaseDatabase.getInstance().getReference().child("Users");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // VÌ ĐÂY LÀ VONG LẬP NÊN NÓ SẼ TÌM ĐÉN data='USER'
                int flag=0;
                for(DataSnapshot data: dataSnapshot.getChildren()){
                    if (data.getKey().equals(idUser) ) {

                        flag=1;
                        Intent intent1=new Intent();
                        intent1.setClass(CreatNickName.this,Menu.class);
                        startActivity(intent1);

                    }
                }
                if(flag==0){



                        create.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                String txt_name=name.getText().toString(); //  lay nickname
                                if(TextUtils.isEmpty(txt_name)){
                                    Toast.makeText(CreatNickName.this,"Nick Name is empty!",Toast.LENGTH_SHORT).show();
                                }else {

                                    FirebaseDatabase.getInstance().getReference().child("Users").child(idUser).child(txt_name).child("room1").setValue("hahah");
                                    Toast.makeText(CreatNickName.this, "Your nickname is " + txt_name, Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent();
                                    intent.setClass(CreatNickName.this, Menu.class);
                                    startActivity(intent);
                                }
                            }
                        });


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
}