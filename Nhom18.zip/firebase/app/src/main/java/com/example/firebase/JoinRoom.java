package com.example.firebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.HashMap;

public class JoinRoom extends AppCompatActivity {
    private EditText linkjoin;
    private Button join;
    private Button nickname;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join_room);
        linkjoin=findViewById(R.id.join_link);
        join=findViewById(R.id.join);
        nickname=findViewById(R.id.info);

        final Intent intent =getIntent();
        final String txt_nickname=intent.getStringExtra("nickname");
        //set nickname
        nickname.setText(txt_nickname);

        final String idUser; //dung final để được xài trong hàm con
        idUser = FirebaseAuth.getInstance().getCurrentUser().getUid();

        // join
        join.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String txt_link=linkjoin.getText().toString();
                final int[] flag = {0};
                final String[] cout = new String[1];
                final String[] nameroom1 = {""};
                if(TextUtils.isEmpty(txt_link)){
                    Toast.makeText(JoinRoom.this,"id/link is empty!",Toast.LENGTH_SHORT).show();
                }else {
                    DatabaseReference reference11 = FirebaseDatabase.getInstance().getReference().child("Rooms");
                    reference11.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot11) {
                            for(DataSnapshot ds : dataSnapshot11.getChildren()){
                                //check id room ton tai trong Rooms
                                if(ds.getKey().equals(txt_link)){
                                    // lay ten room
                                    for(DataSnapshot d : ds.getChildren()){
                                        nameroom1[0] =d.getKey();
                                        cout[0] =String.valueOf(d.getChildrenCount());
                                        break;
                                    }
                                    flag[0] =1;
                                    break;
                                }
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                        }
                    });
                    DatabaseReference reference12 = FirebaseDatabase.getInstance().getReference().child("Users").child(idUser).child(txt_nickname);
                    reference12.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot12) {
                            for(DataSnapshot ds : dataSnapshot12.getChildren()){
                                // check user da join room nay chua
                                if(ds.getKey().equals(txt_link)){
                                    flag[0]=0;
                                    break;
                                }
                            }
                            if(flag[0]==1){
                                // chuyen sang active khac xu ly
                                Intent intent23 = new Intent(JoinRoom.this,Tmp.class);
                                String[] arrrayCourse={txt_link,nameroom1[0],cout[0],txt_nickname,idUser};
                                intent23.putExtra("data",arrrayCourse);
                                startActivity(intent23);
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                        }
                    });
                }
            }
        });
    }
}