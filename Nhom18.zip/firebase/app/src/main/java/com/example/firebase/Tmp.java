package com.example.firebase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.google.firebase.database.FirebaseDatabase;

public class Tmp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tmp);
        Intent intent=getIntent();
        String[] data=intent.getStringArrayExtra("data");
        int coat= Integer.parseInt(data[2])+1;

        FirebaseDatabase.getInstance().getReference().child("Rooms").child(data[0]).child(data[1]).child(""+coat).setValue(data[3]+":Welcome !" + data[3]);

        FirebaseDatabase.getInstance().getReference().child("Users").child(data[4]).child(data[3]).child(data[0]).setValue(data[1]);
        /*Intent intent14=new Intent();
        intent14.setClass(Tmp.this,ListRoom.class);
        startActivity(intent14);*/
        Toast.makeText(Tmp.this,"Join success!",Toast.LENGTH_SHORT).show();

    }


}